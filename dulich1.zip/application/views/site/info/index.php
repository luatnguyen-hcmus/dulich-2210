<?php 
	
	
		echo "<h1>".$info_list->title."</h1>";
		echo "<br />";
		echo $info_list->content;
	
?>