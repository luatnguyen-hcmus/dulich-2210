<meta charset="utf-8">
        <title>vietnam tour</title>
        <meta name="description" content=" Vietnam Travel  is a team of people with a full of passion, energy and experience.
Travel will surely provide you package tours with high quality to travel in Vietnam and Cambodia.">
        <meta name="keywords" content=" vietnam tour, package tour in vietnam, hanoi, ho chi minh, vietnam tour from north to south, vietnam agent reviews">
        <!-- <base href="http://swallowtravel.com"> -->

        <base href="<?php echo base_url() ?>"> 
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <meta property="og:title" content=" vietnam tour, package tour in vietnam, vietnam tour from north to south, sapa tour, halong tour, mekong tour">
        <meta property="og:type" content="article" />
        <meta property="og:image" content="<?php echo public_url('site/images/logo.png') ?>">
        <meta property="og:description" content=" Vietnam Travel  is a team of people with a full of passion, energy and experience. Travel will surely provide you package tours with high quality to travel in Vietnam and Cambodia.">
        

        

        <link rel="shortcut icon" href="<?php echo public_url('site/images/logo.png') ?>">

        <link href="<?php echo public_url('site/css/style.css')?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo public_url('site/font-awesome/css/font-awesome.css') ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo public_url('site/css/jquery.smartmenus.bootstrap.css')?>" rel="stylesheet" />
        <link href="<?php echo public_url('site/css/jquery-ui.css')?>" rel="stylesheet" />
        <link href="<?php echo public_url('site/css/jquery-ui.theme.css')?>" rel="stylesheet" />

        <link href="<?php echo public_url('site/css/bootstrap.min.css')?>" rel="stylesheet" />
        <link href="<?php echo public_url('site/css/Custom.css')?>" rel="stylesheet" />
                

       <script src="<?php echo public_url('site/js/jquery-1.9.1.js')?>"></script>
        <script src="<?php echo public_url('site/js/jquery-ui.js')?>"></script>
        <script src="<?php echo public_url('site/js/bootstrap.min.js')?>"></script>
        <script src="<?php echo public_url('site/js/jquery.smartmenus.bootstrap.min.js')?>"></script>
        <script src="<?php echo public_url('site/js/jquery.smartmenus.js')?>"></script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-99578229-1', 'auto');
  ga('send', 'pageview');

</script>


