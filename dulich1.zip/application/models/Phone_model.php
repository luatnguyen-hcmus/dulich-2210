<?php 
	Class Phone_model extends MY_Model{
		var $table = 'phone';
	}