<?php 
	Class Tour_model extends MY_Model{
		var $table = 'tours';
	}